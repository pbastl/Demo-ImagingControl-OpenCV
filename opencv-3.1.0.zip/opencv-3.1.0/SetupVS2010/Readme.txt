Use of OpenCV:
We add the necessary OpenCV includes, libraries and binaries build from opencv-3.1.0 in MS VisualStudio2010. We recommend download and build your own binaries of OpenCV.

Property sheets:
For simplify creating of new project with OpenCV we use property sheets. Edit the property sheet according versions of your OpenCV and VisualStudio. Only need to do than is to set up new project and in the PropertyManager insert the property sheets for Debug and Release.

The paths in the property sheets are relative to the system variables:
OPENCV_3_1_0_DIR - show into the placement of "opencv-3.1.0\opencv\build\"

After setup path is necessary restart program (or computer)


